"""공고 상세 페이지 링크 → 그 게시물의 첨부파일 전부 다운로드.

사용 예:
    python scripts/fetch_notice_attachments.py "<공고 URL>" --out-dir "<저장 폴더>"
    python scripts/fetch_notice_attachments.py "<URL1>" "<URL2>" --out-dir "<폴더>"
    python scripts/fetch_notice_attachments.py --url-file links.txt --out-dir "<폴더>"
    python scripts/fetch_notice_attachments.py --dry-run "<URL>"        # 받지 않고 미리보기

동작:
    1) 공고 상세 페이지를 가져와 공고 '제목'을 추출하고,
    2) 저장 폴더 안에 "NN_공고제목" 하위 폴더를 만든 뒤,
    3) 그 게시물의 첨부파일을 모두 내려받는다.

K-Startup(k-startup.go.kr)·기업마당(bizinfo.go.kr) 및 일반 정부포털의
직접 다운로드 링크를 지원한다. monitor.py 의 수집기/추출기를 재사용하되
파일명 인코딩(CP949/EUC-KR)·차단 HTML 거부를 자체적으로 보강한다.
이 스크립트는 메일을 전혀 보내지 않으며 monitor.py 를 수정하지 않는다.
"""
from __future__ import annotations

import argparse
import json
import logging
import mimetypes
import os
import re
import subprocess
import sys
import unicodedata
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import unquote, unquote_plus, urlparse

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Windows 한글 깨짐 방지 — import/에러 출력보다 먼저 고정
os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PYTHONIOENCODING", "utf-8")


def _force_utf8_console() -> None:
    """cp949 콘솔에서 한글·이모지 출력이 깨지거나 죽지 않게 한다."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


_force_utf8_console()

try:
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
except ImportError:
    pass

# monitor.py 는 import 시점에 아래 env 를 요구한다(실제 값은 불필요 — 메일 안 보냄).
os.environ.setdefault("BIZINFO_API_KEY", "dummy")
os.environ.setdefault("ANTHROPIC_API_KEY", "dummy")
os.environ.setdefault("GMAIL_ADDRESS", "dummy@example.com")
os.environ.setdefault("GMAIL_APP_PASSWORD", "dummy")


def _git(*args: str) -> subprocess.CompletedProcess | None:
    """저장소 루트에서 git 을 실행한다(git 없음·실행 실패면 None)."""
    try:
        return subprocess.run(
            ["git", "-C", str(ROOT), *args],
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=60,
        )
    except (OSError, subprocess.SubprocessError):
        return None


def _deleted_tracked_files() -> list[str]:
    """git 이 관리하는데 작업 폴더에서는 사라진 파일 목록(진단 불가면 빈 목록)."""
    proc = _git("ls-files", "--deleted")
    if proc is None or proc.returncode != 0:
        return []
    return [name for name in proc.stdout.splitlines() if name.strip()]


def selfcheck_repo_files(verbose: bool = False) -> int:
    """프로그램 파일 소실을 감지해 알리고 원본에서 되살린다. 0=정상, 1=미해결.

    2026-07-31 실제 사고: 다른 세션의 중단된 git 작업으로
    mail_core/storage/seen_ids_prune.py 등 15개가 작업 폴더에서 사라져,
    이 프로그램이 실행 즉시 ModuleNotFoundError 로 죽었다(런처 창이 그냥 닫혀
    사용자에게는 원인이 보이지 않았다). 그래서 실행 전에 먼저 점검한다.
    복구는 git 인덱스를 잠그지 않는 checkout-index 로 하므로 같은 폴더에서
    작업 중인 다른 세션의 git 작업을 방해하지 않는다.
    """
    missing = _deleted_tracked_files()
    if not missing:
        if verbose:
            print("✅ 자가진단: 프로그램 파일 이상 없음")
        return 0

    print(f"\n⚠ 자가진단: 프로그램 파일 {len(missing)}개가 사라졌습니다(이대로면 실행이 죽습니다).")
    for name in missing[:5]:
        print(f"   · {name}")
    if len(missing) > 5:
        print(f"   · … 외 {len(missing) - 5}개")

    print("   🔧 저장돼 있던 원본에서 되살리는 중…")
    for i in range(0, len(missing), 100):   # 명령줄 길이 제한 회피
        _git("checkout-index", "-f", "--", *missing[i:i + 100])

    still = _deleted_tracked_files()
    if still:
        print(f"   ❌ {len(still)}개를 되살리지 못했습니다(다른 프로그램이 폴더를 쓰는 중일 수 있음).")
        print(f"      잠시 뒤 다시 실행해 보고, 계속 실패하면 이렇게 알려주세요: {ROOT} 파일이 사라졌어요")
        return 1
    print(f"   ✅ {len(missing)}개 되살렸습니다 — 계속 진행합니다.\n")
    return 0


if "--selfcheck" in sys.argv:      # 런처(cmd)가 실행 직전에 부르는 진단 전용 모드
    raise SystemExit(selfcheck_repo_files(verbose=True))
selfcheck_repo_files()             # 평소 실행에서도 무거운 import 전에 먼저 점검

import httpx  # noqa: E402
from bs4 import BeautifulSoup  # noqa: E402

import monitor  # noqa: E402
from scripts.download_kstartup_targets import (  # noqa: E402
    AttachmentCandidate,
    EXT_RE,
    egov_context_fallback_url,
    extract_attachment_candidates,
    extract_outbound_urls,
    safe_filename,
    unique_path,
)

log = logging.getLogger(__name__)

# 제목으로 부적합한 노이즈(로그인/공통 UI 텍스트)
TITLE_NOISE = {
    "모집중", "마감", "공고", "공지", "알림", "상세화면", "상세", "notice",
    "중소벤처24 통합로그인 사이트", "통합로그인", "로그인", "k-startup 창업지원포털",
    "공지사항", "공지사항 상세", "공고 상세", "보도자료",
}
TITLE_TAIL_RE = re.compile(r"\s*[>《<]\s*상세화면\s*$")
HTML_HEAD_RE = re.compile(rb"^\s*<(?:!doctype|html|head|body|center|br|table)\b", re.IGNORECASE)
DOC_EXT_RE = re.compile(r"\.(hwp|hwpx|pdf|docx?|xlsx?|pptx?|zip|7z|rar|txt|jpe?g|png|gif)$", re.IGNORECASE)
# 사이트 공통 안내서·도움말(공고 첨부가 아닌 네비게이션 파일) — 후보에서 제외
SITE_GUIDE_RE = re.compile(r"/guide/|/help/|/manual/|manual\.pdf|user_?guide|/common/.*manual", re.IGNORECASE)

# ── 첨부 안전 가드(#27 악성첨부·#28 ZIP Bomb) ──
MAX_ATTACH_BYTES = 60 * 1024 * 1024   # 파일당 상한 60MB — 초대용량·압축폭탄 다운로드 차단
MAX_ATTACH_COUNT = 30                  # 공고당 첨부 개수 상한 — 악성 페이지의 대량 링크 폭주 차단
# 실행·스크립트 확장자 — 공고 첨부로 저장 금지(악성코드 차단)
BLOCKED_EXTENSIONS = frozenset({
    "exe", "bat", "cmd", "com", "scr", "pif", "msi", "msp", "cpl", "dll", "sys",
    "js", "jse", "vbs", "vbe", "wsf", "wsh", "ps1", "psm1", "jar", "apk", "app",
    "sh", "bash", "reg", "lnk", "hta", "gadget", "cab",
})


def is_blocked_extension(name: str) -> bool:
    """실행/스크립트 확장자면 True — 공고 첨부로 저장하지 않는다(악성 첨부 차단)."""
    ext = Path(str(name or "")).suffix.lstrip(".").lower()
    return ext in BLOCKED_EXTENSIONS


def _read_capped(resp: "httpx.Response", max_bytes: int = MAX_ATTACH_BYTES) -> bytes:
    """스트리밍으로 최대 max_bytes 까지만 읽는다. 초과하면 RuntimeError(중단·미저장).

    r.content 를 통째로 메모리에 올리기 전에 청크 단위로 누적·상한 검사해 초대용량/압축폭탄
    다운로드로 디스크·메모리가 고갈되는 것을 막는다.
    """
    chunks: list[bytes] = []
    total = 0
    for chunk in resp.iter_bytes():
        total += len(chunk)
        if total > max_bytes:
            raise RuntimeError(f"첨부 크기 상한 초과(> {max_bytes // (1024 * 1024)}MB) — 저장 거부")
        chunks.append(chunk)
    return b"".join(chunks)


@dataclass
class FileResult:
    notice_title: str
    detail_url: str
    status: str
    file_name: str = ""
    save_path: str = ""
    file_url: str = ""
    error: str = ""


def decode_cd_filename(cd: str) -> str:
    """content-disposition 헤더에서 올바른(한글 복원) 파일명을 뽑는다.

    httpx 는 헤더 바이트를 latin-1 로 디코드해 노출하므로, 한국 정부사이트가
    CP949/EUC-KR 로 보낸 한글 파일명은 깨져 보인다. latin-1 로 되돌린 뒤
    적절한 인코딩으로 재디코딩한다. RFC 5987(filename*) 도 우선 처리한다.
    """
    if not cd:
        return ""
    # 1) RFC 5987: filename*=charset'lang'<percent-encoded>
    m = re.search(r"filename\*\s*=\s*([\w.\-]+)?'[^']*'([^;]+)", cd, re.IGNORECASE)
    if m:
        charset = (m.group(1) or "utf-8").strip()
        value = m.group(2).strip().strip('"')
        try:
            return unquote(value, encoding=charset, errors="strict")
        except Exception:
            try:
                return unquote(value)
            except Exception:
                pass
    # 2) filename="..." 또는 filename=...
    m = re.search(r'filename\s*=\s*"([^"]*)"', cd, re.IGNORECASE)
    if not m:
        m = re.search(r"filename\s*=\s*([^;]+)", cd, re.IGNORECASE)
    if not m:
        return ""
    name = m.group(1).strip().strip('"').strip()
    # 진짜 퍼센트 인코딩(%XX)일 때만 푼다. 이때의 '+' 는 Java URLEncoder 식 공백(캠코 등).
    # ('%' 문자만 있는 raw 파일명에서 리터럴 '+' 를 공백으로 오손상하지 않도록 %XX 로 한정)
    if re.search(r"%[0-9A-Fa-f]{2}", name):
        try:
            decoded = unquote_plus(name)
            if decoded:
                name = decoded
        except Exception:
            pass
    # latin-1 로 노출된 CP949/EUC-KR/UTF-8 한글 복원
    if any(ord(ch) > 0x7F for ch in name):
        try:
            raw = name.encode("latin-1")
        except Exception:
            raw = b""
        for enc in ("cp949", "euc-kr", "utf-8"):
            try:
                dec = raw.decode(enc)
            except Exception:
                continue
            if "�" in dec:
                continue
            # 한글이 하나라도 복원되면 채택(영문/숫자만이면 원본 유지가 안전)
            if re.search(r"[가-힣]", dec):
                return dec.strip()
    return name.strip()


def _good_title(text: str) -> str | None:
    text = " ".join((text or "").split())
    text = TITLE_TAIL_RE.sub("", text).strip()
    if not text or len(text) < 4:
        return None
    if text.lower() in TITLE_NOISE:
        return None
    return text


def _title_from_view_table(soup: BeautifulSoup) -> str | None:
    """게시판 상세 '표'의 제목 행에서 제목을 뽑는다(캠코 등 eGov 게시판 공통).

    <th>제목</th><td>…</td> 또는 <td data-label="제목">…</td> 패턴.
    h2/h3 같은 일반 셀렉터보다 먼저 봐야 메뉴명('공지사항')을 제목으로 오인하지 않는다.
    """
    for td in soup.select('td[data-label="제목"], td[date-label="제목"]'):
        good = _good_title(td.get_text(" ", strip=True))
        if good:
            return good
    for th in soup.find_all("th"):
        if th.get_text(strip=True) in {"제목", "공고명", "공고제목"}:
            td = th.find_next_sibling("td")
            if td is not None:
                good = _good_title(td.get_text(" ", strip=True))
                if good:
                    return good
    return None


def extract_notice_title(html: str, url: str) -> str:
    """공고 상세 페이지에서 폴더명으로 쓸 제목을 추출한다."""
    soup = BeautifulSoup(html, "html.parser")

    og = soup.select_one('meta[property="og:title"]')
    if og:
        good = _good_title(og.get("content", ""))
        if good:
            return good

    from_table = _title_from_view_table(soup)
    if from_table:
        return from_table

    for sel in (".title", "h3.tit", ".view_title", ".board_view .tit",
                ".tbl_view .tit", ".bbsV_tit", "h3", "h2.tit", ".pbanc_tit"):
        el = soup.select_one(sel)
        if el:
            good = _good_title(el.get_text(" ", strip=True))
            if good:
                return good

    if soup.title and soup.title.string:
        good = _good_title(soup.title.string)
        if good:
            return good

    # 최후: URL 식별자 기반 이름
    parsed = urlparse(url)
    ident = ""
    for key in ("nttNo", "pbancSn", "pblancId", "policyno", "atchFileId", "wr_id", "seq", "idx", "no"):
        m = re.search(rf"{key}=([\w\-]+)", parsed.query, re.IGNORECASE)
        if m:
            ident = m.group(1)
            break
    return f"공고_{ident or parsed.netloc}"


GENERIC_TITLES = {"주요사업", "사업공고", "공지사항", "공고", "공지", "전체", "알림마당", "notice", "list"}
_TITLE_SUFFIX_RE = re.compile(
    r"[\s_]*(공고문|재공고|공고|신청\s*서식|신청서|접수\s*서식|양식|서식|"
    r"안내문|안내|운영지침|붙임\s*\d*|별첨\s*\d*|첨부\s*\d*)\s*$")


def _looks_generic(title: str) -> bool:
    """제목이 메뉴명/사이트명/URL폴백 등 '진짜 공고명이 아닌' 약한 값인지."""
    t = " ".join((title or "").split())
    if not t or t.startswith("공고_") or len(t) < 6:
        return True
    if t in GENERIC_TITLES:
        return True
    # "○○ : 정보통신산업진흥원" 같은 사이트명 꼬리
    if re.search(r"진흥원\s*$", t) and len(t) < 25:
        return True
    return False


def _title_from_label(label: str) -> str:
    """첨부 링크 라벨/파일명에서 공고 제목을 유추한다(JS 렌더링 사이트 폴백)."""
    s = " ".join((label or "").split())
    s = re.sub(r"\([^)]*\)", "", s)          # (파일크기: 73 KB) 등 제거
    s = re.sub(r"\[[^\]]*다운로드[^\]]*\]", "", s)
    s = re.sub(r"\.(hwp|hwpx|pdf|docx?|xlsx?|pptx?|zip|7z|rar)\b.*$", "", s, flags=re.IGNORECASE)
    s = " ".join(s.split())
    s = re.sub(r"^(붙임|별첨|첨부)\s*\d*\s*[.)\-:]\s*", "", s)   # 앞 '붙임.'·'별첨1)' 류 제거
    s = _TITLE_SUFFIX_RE.sub("", s)
    s = " ".join(s.split()).strip(" _-·.")
    if len(s) >= 6 and re.search(r"[가-힣A-Za-z0-9]", s):
        return s
    return ""


def _new_client() -> httpx.Client:
    return httpx.Client(timeout=180, follow_redirects=True,
                        headers={**monitor.HTTP_HEADERS}, verify=False)


def fetch_html(url: str, client: httpx.Client | None = None) -> str:
    """공고 상세 페이지 HTML 을 가져온다(요청 사이트 origin 을 Referer 로).

    client 를 넘기면 그 세션을 재사용한다(쿠키 유지 — 그누보드 등 세션 검증 사이트 대응).
    """
    parsed = urlparse(url)
    referer = f"{parsed.scheme}://{parsed.netloc}/" if parsed.scheme else ""
    headers = {"Referer": referer} if referer else {}
    if client is not None:
        r = client.get(url, headers=headers)
        r.raise_for_status()
        return r.text
    with _new_client() as own:
        r = own.get(url, headers=headers)
        r.raise_for_status()
        return r.text


def _looks_like_html_body(content: bytes) -> bool:
    head = content[:512].lstrip()
    return bool(HTML_HEAD_RE.match(head))


def download_attachment(cand: AttachmentCandidate, detail_url: str, notice_dir: Path, idx: int,
                        client: httpx.Client | None = None) -> tuple[str, Path]:
    """첨부 후보 하나를 내려받아 저장한다(파일명 인코딩 복원·차단 HTML 거부).

    client 를 넘기면 상세 페이지를 읽은 세션을 재사용한다(쿠키 유지).
    """
    own = client is None
    cli = client or _new_client()
    try:
        # 스트리밍으로 받아 크기 상한(#28)을 넘으면 중단·미저장. Content-Length 로 조기 차단.
        with cli.stream("GET", cand.url, headers={"Referer": detail_url}) as r:
            r.raise_for_status()
            ctype = r.headers.get("content-type", "").lower()
            cd = r.headers.get("content-disposition", "")
            clen = r.headers.get("content-length", "")
            if clen.isdigit() and int(clen) > MAX_ATTACH_BYTES:
                raise RuntimeError(
                    f"첨부 크기 상한 초과(Content-Length {int(clen) // (1024 * 1024)}MB) — 저장 거부")
            content = _read_capped(r)   # 실제 바이트 캡(헤더 위조 대비)

        name_from_cd = decode_cd_filename(cd)
        cd_has_doc_ext = bool(name_from_cd and DOC_EXT_RE.search(name_from_cd))
        url_has_doc_ext = bool(EXT_RE.search(cand.url))

        # 차단/오류 HTML 을 첨부로 저장하지 않는다(진짜 바이너리는 HTML 마커로 시작하지 않음).
        if _looks_like_html_body(content):
            raise RuntimeError(f"첨부가 아닌 HTML 응답(차단/오류 페이지 가능): {cand.url}")
        # content-type 단독 검사는 확장자 힌트가 있으면 면제(구형 서버의 타입 오설정 대응)
        if not cd_has_doc_ext and not url_has_doc_ext and "text/html" in ctype:
            raise RuntimeError(f"첨부가 아닌 HTML 응답(차단/오류 페이지 가능): {cand.url}")

        file_name = name_from_cd or _filename_from_url_or_label_name(cand, idx)
        file_name = safe_filename(file_name, 180)
        if not DOC_EXT_RE.search(file_name):
            ext = _guess_ext(ctype, cand.url)
            if ext and not file_name.lower().endswith(ext):
                file_name = f"{file_name}{ext}"

        # 실행/스크립트 확장자 첨부는 저장 거부(#27 악성 첨부).
        if is_blocked_extension(file_name):
            raise RuntimeError(f"실행/스크립트 확장자 첨부 차단: {file_name}")

        save_path = unique_path(notice_dir / file_name)
        save_path.write_bytes(content)
        return file_name, save_path
    finally:
        if own:
            cli.close()


def _egov_ctx_variant(cand: AttachmentCandidate, detail_url: str) -> AttachmentCandidate | None:
    """루트 eGov 합성 URL 실패 시 시도할 컨텍스트 패스 변형(없으면 None)."""
    if cand.source != "egov-downfile":
        return None
    ctx_url = egov_context_fallback_url(cand.url, detail_url)
    if not ctx_url or ctx_url == cand.url:
        return None
    return AttachmentCandidate(url=ctx_url, label=cand.label, source="egov-downfile-ctx")


def _download_with_egov_fallback(cand: AttachmentCandidate, detail_url: str, notice_dir: Path,
                                 idx: int, client: httpx.Client | None):
    """다운로드 시도 + eGov 컨텍스트 패스 1회 폴백(TASK-010).

    루트 /cmm/fms/FileDown.do 합성이 4xx 또는 HTML(soft-404)이면 상세 URL 의
    첫 세그먼트(/portal 등)를 붙인 변형으로 한 번 더 시도한다.
    성공 시 (실제 사용한 후보, 파일명, 경로), 실패 시 원래 오류를 그대로 던진다.
    """
    try:
        file_name, save_path = download_attachment(cand, detail_url, notice_dir, idx, client=client)
        return cand, file_name, save_path
    except (httpx.HTTPStatusError, RuntimeError) as exc:
        retryable = isinstance(exc, RuntimeError) or 400 <= exc.response.status_code < 500
        var = _egov_ctx_variant(cand, detail_url) if retryable else None
        if var is None:
            raise
        try:
            file_name, save_path = download_attachment(var, detail_url, notice_dir, idx, client=client)
        except Exception:
            raise exc  # 폴백도 실패 — 원 오류 기준으로 보고
        return var, file_name, save_path


def _guess_ext(ctype: str, url: str) -> str:
    m = EXT_RE.search(url)
    if m:
        return f".{m.group(1).lower()}"
    mt = (ctype or "").split(";")[0].strip()
    return mimetypes.guess_extension(mt) or ""


def _filename_from_url_or_label_name(cand: AttachmentCandidate, idx: int) -> str:
    parsed = urlparse(cand.url)
    base = unquote(Path(parsed.path).name)
    if base and "." in base:
        return base
    label = (cand.label or f"attachment_{idx}").strip()
    return f"{idx:02d}_{label}"


def resolve_notice_dir(out_dir: Path, title: str, number: bool) -> Path:
    """저장 폴더 안의 공고별 하위 폴더 경로를 결정한다.

    같은 제목(번호 prefix 무시) 폴더가 이미 있으면 재사용하고,
    없으면 number=True 일 때 기존 최대 번호+1 을 prefix 로 붙인다.
    """
    safe = safe_filename(title, 110)
    existing_dirs = [d for d in out_dir.iterdir() if d.is_dir()] if out_dir.exists() else []

    for d in existing_dirs:
        stripped = re.sub(r"^\d+[_.\-]\s*", "", d.name)
        if stripped == safe or d.name == safe:
            return d

    if number:
        nums = []
        for d in existing_dirs:
            m = re.match(r"^(\d+)[_.\-]", d.name)
            if m:
                nums.append(int(m.group(1)))
        nxt = (max(nums) + 1) if nums else 1
        return out_dir / f"{nxt:02d}_{safe}"
    return out_dir / safe


def _dedup_key(file_name: str, size: int) -> tuple[str, int]:
    """파일명(공백·구두점 무시)+크기로 같은 첨부의 중복을 식별한다."""
    norm = re.sub(r"[\s+_.\-]", "", file_name).lower()
    return (norm, size)


def gather_candidates(url: str, html: str, client: httpx.Client | None = None) -> list[AttachmentCandidate]:
    """상세 페이지에서 첨부 후보를 모은다.

    상세 페이지에 직접 첨부가 있으면 그것만 쓴다(K-Startup 원본사이트 중복 방지).
    상세에 첨부가 없을 때만 K-Startup '원본/사업안내' 외부 페이지를 추가로 본다.
    """
    candidates = extract_attachment_candidates(html, url)
    if not candidates and "k-startup.go.kr" in url.lower():
        for outbound in extract_outbound_urls(html, url)[:5]:
            try:
                candidates.extend(extract_attachment_candidates(fetch_html(outbound, client=client), outbound))
            except Exception as exc:
                log.warning("외부 페이지 확인 실패(%s): %s", outbound, exc)
    # 사이트 공통 안내서·도움말(매뉴얼 등)은 공고 첨부가 아니므로 제외
    candidates = [c for c in candidates if not SITE_GUIDE_RE.search(c.url)]
    return candidates


def process_url(url: str, out_dir: Path, dry_run: bool) -> list[FileResult]:
    url = url.strip()
    results: list[FileResult] = []
    # 상세 읽기~첨부 다운로드를 하나의 세션(쿠키 공유)으로 — 그누보드 등 세션 검증 사이트 대응
    client = _new_client()
    try:
        try:
            html = fetch_html(url, client=client)
        except Exception as exc:
            return [FileResult("", url, "PAGE_FETCH_FAILED", error=str(exc))]

        title = extract_notice_title(html, url)

        try:
            candidates = gather_candidates(url, html, client=client)
        except Exception as exc:
            return [FileResult(title, url, "EXTRACT_FAILED", error=str(exc))]

        # 중복 URL 제거(순서 유지)
        seen_urls: set[str] = set()
        candidates = [c for c in candidates if not (c.url in seen_urls or seen_urls.add(c.url))]

        if not candidates:
            return [FileResult(title, url, "NO_ATTACHMENTS")]

        # 공고당 첨부 개수 상한(#27) — 악성/오동작 페이지가 수백 개 링크를 노출해도 폭주 방지.
        if len(candidates) > MAX_ATTACH_COUNT:
            log.warning("첨부 후보 %d개 > 상한 %d — 상위 %d개만 처리",
                        len(candidates), MAX_ATTACH_COUNT, MAX_ATTACH_COUNT)
            candidates = candidates[:MAX_ATTACH_COUNT]

        # 제목이 메뉴명/사이트명 등으로 약하면 첫 첨부 파일명에서 보정(NIPA 등 JS 렌더링)
        if _looks_generic(title):
            alt = _title_from_label(candidates[0].label)
            if alt:
                title = alt

        notice_dir = resolve_notice_dir(out_dir, title, number=True)
        if not dry_run:
            notice_dir.mkdir(parents=True, exist_ok=True)

        seen_files: set[tuple[str, int]] = set()
        for idx, cand in enumerate(candidates, start=1):
            if dry_run:
                results.append(FileResult(
                    notice_title=title, detail_url=url, status="DRY_RUN",
                    file_name=f"(예정) {cand.label[:40]}", file_url=cand.url,
                    save_path=str(notice_dir),
                ))
                continue
            try:
                cand, file_name, save_path = _download_with_egov_fallback(
                    cand, url, notice_dir, idx, client)
            except httpx.HTTPStatusError as exc:
                # 4xx 는 '진짜 첨부가 아닌 후보'(미리보기/깨진 링크) — 조용히 제외
                code = exc.response.status_code
                status = "NOT_A_FILE" if 400 <= code < 500 else "DOWNLOAD_FAILED"
                results.append(FileResult(title, url, status, file_url=cand.url, error=f"HTTP {code}"))
                continue
            except RuntimeError as exc:
                # HTML 차단/오류 페이지 — 첨부 아님으로 조용히 제외
                results.append(FileResult(title, url, "NOT_A_FILE", file_url=cand.url, error=str(exc)))
                continue
            except Exception as exc:
                results.append(FileResult(title, url, "DOWNLOAD_FAILED", file_url=cand.url, error=str(exc)))
                continue

            key = _dedup_key(file_name, save_path.stat().st_size)
            if key in seen_files:
                try:
                    save_path.unlink()
                except Exception:
                    pass
                results.append(FileResult(title, url, "DUPLICATE", file_name=file_name, file_url=cand.url))
                continue
            seen_files.add(key)
            results.append(FileResult(
                notice_title=title, detail_url=url, status="DOWNLOADED",
                file_name=file_name, save_path=str(save_path), file_url=cand.url,
            ))

        # 받은 파일이 하나도 없으면 빈 공고 폴더를 남기지 않는다
        if not dry_run and not any(r.status == "DOWNLOADED" for r in results):
            try:
                if notice_dir.exists() and not any(notice_dir.iterdir()):
                    notice_dir.rmdir()
            except Exception:
                pass

        return results
    finally:
        client.close()


CONFIG_PATH = ROOT / "scripts" / "notice_download_config.json"


def _load_config() -> dict:
    """저장 폴더 등 기본 설정을 UTF-8 JSON 에서 읽는다(없으면 빈 dict)."""
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _default_out_dir() -> Path:
    """설정이 비었을 때 쓰는 기본 저장 폴더(바탕화면/지원사업_공고첨부).

    비개발자 PC·OneDrive 한글 바탕화면까지 후보로 본다.
    """
    home = Path.home()
    candidates = [
        home / "Desktop",
        home / "OneDrive" / "Desktop",
        home / "OneDrive" / "바탕 화면",
        home / "바탕 화면",
    ]
    userprofile = os.environ.get("USERPROFILE", "").strip()
    if userprofile:
        up = Path(userprofile)
        candidates.extend([
            up / "Desktop",
            up / "OneDrive" / "Desktop",
            up / "OneDrive" / "바탕 화면",
            up / "바탕 화면",
        ])
    for base in candidates:
        if base.is_dir():
            return base / "지원사업_공고첨부"
    return home / "지원사업_공고첨부"


def load_urls(args: argparse.Namespace) -> list[str]:
    urls: list[str] = []
    for raw in args.urls or []:
        # 한 칸/줄에 여러 링크가 붙어 들어와도 분리
        urls.extend(re.findall(r"https?://[^\s'\"]+", raw))
        if not re.search(r"https?://", raw) and raw.strip():
            urls.append(raw.strip())
    if args.url_file:
        text = Path(args.url_file).read_text(encoding="utf-8")
        for line in text.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                urls.append(line)
    # 중복 제거(순서 유지)
    out: list[str] = []
    seen: set[str] = set()
    for u in urls:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def _print_results(results: list[FileResult], dry_run: bool, open_flag: bool, opened_dirs: set[str]) -> None:
    title = results[0].notice_title if results else ""
    downloaded = [r for r in results if r.status == "DOWNLOADED"]
    for r in results:
        if r.status == "DOWNLOADED":
            print(f"  ✅ {r.file_name}")
        elif r.status == "DRY_RUN":
            print(f"  ▶ {r.file_name}")
        elif r.status == "NO_ATTACHMENTS":
            print("  ⚠ 첨부파일을 찾지 못했습니다")
        elif r.status in ("PAGE_FETCH_FAILED", "EXTRACT_FAILED", "DOWNLOAD_FAILED"):
            print(f"  ❌ {r.status}: {r.error}")
        # NOT_A_FILE(미리보기·외부링크)·DUPLICATE(중복)는 조용히 제외
    if title:
        print(f"  📁 공고: {title}")
    if downloaded and not dry_run:
        folder = str(Path(downloaded[0].save_path).parent)
        print(f"  💾 저장 위치: {folder}")
        if open_flag and folder not in opened_dirs:
            opened_dirs.add(folder)
            try:
                os.startfile(folder)  # type: ignore[attr-defined]
            except Exception:
                pass


def _handle_url(url: str, out_dir: Path, dry_run: bool, open_flag: bool,
                opened_dirs: set[str], all_results: list[FileResult]) -> None:
    print(f"\n🔗 처리 중: {url}")
    results = process_url(url, out_dir, dry_run)
    all_results.extend(results)
    _print_results(results, dry_run, open_flag, opened_dirs)


def _write_manifest(out_dir: Path, dry_run: bool, all_results: list[FileResult]) -> dict:
    manifest = out_dir / "_download_log.json"
    counts: dict[str, int] = {}
    for r in all_results:
        counts[r.status] = counts.get(r.status, 0) + 1
    generated_at = datetime.now().isoformat(timespec="seconds")
    summary = {
        "generated_at": generated_at,
        "out_dir": str(out_dir),
        "dry_run": dry_run,
        "total_urls": len({r.detail_url for r in all_results}),
        "status_counts": counts,
        "results": [asdict(r) for r in all_results],
    }
    try:
        prev = json.loads(manifest.read_text(encoding="utf-8")) if manifest.exists() else None
        hist = prev["history"][-19:] if isinstance(prev, dict) and isinstance(prev.get("history"), list) else []
    except Exception:
        hist = []
    summary["history"] = hist + [{"at": generated_at, "counts": counts}]
    manifest.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return counts


def _print_summary(counts: dict, link_count: int) -> None:
    ok = counts.get("DOWNLOADED", 0)
    skipped = counts.get("NOT_A_FILE", 0) + counts.get("DUPLICATE", 0)
    real_fail = (counts.get("DOWNLOAD_FAILED", 0) + counts.get("PAGE_FETCH_FAILED", 0)
                 + counts.get("EXTRACT_FAILED", 0))
    print(f"\n{'='*48}")
    print(f"📊 완료: 받은 파일 {ok}개 / 처리한 링크 {link_count}개")
    if skipped:
        print(f"   ℹ 미리보기·중복·외부링크 {skipped}건 자동 제외(첨부 아님)")
    if counts.get("NO_ATTACHMENTS"):
        print(f"   ⚠ 첨부를 찾지 못한 링크 {counts['NO_ATTACHMENTS']}건")
    if real_fail:
        print(f"   ❌ 실제 실패 {real_fail}건 (자세한 내용은 _download_log.json)")


def _try_notify_popup(message: str) -> None:
    """Windows 토스트/팝업(있으면). 실패해도 CLI 는 계속."""
    script = Path.home() / ".claude" / "scripts" / "notify_popup.ps1"
    if not script.is_file():
        return
    try:
        subprocess.run(
            [
                "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-File", str(script), "-Kind", "batch",
            ],
            input=message,
            text=True,
            encoding="utf-8",
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        pass


def _notify_download_done(ok: int, link_count: int, out_dir: Path) -> None:
    line = f"첨부 {ok}개 저장됨 — {out_dir}"
    _try_notify_popup(line)


def main() -> int:
    _force_utf8_console()   # cp949 콘솔/파이프에서 이모지 출력이 죽지 않게(UTF-8 고정)
    parser = argparse.ArgumentParser(
        description="공고 상세 페이지 링크의 첨부파일을 모두 다운로드한다.")
    parser.add_argument("urls", nargs="*", help="공고 상세 페이지 URL(여러 개 가능)")
    parser.add_argument("--url-file", help="URL 목록 파일(한 줄에 1개)")
    parser.add_argument("--out-dir", help="저장 폴더(미지정 시 notice_download_config.json 의 out_dir 사용)")
    parser.add_argument("--dry-run", action="store_true", help="받지 않고 받을 목록만 미리보기")
    parser.add_argument("--open", action="store_true", help="완료 후 저장 폴더 열기(Windows)")
    parser.add_argument("--notify", action="store_true",
                        help="완료 시 Windows 팝업(가능할 때만)")
    parser.add_argument("--interactive", action="store_true", help="링크를 직접 입력받아 반복 처리(더블클릭 런처용)")
    parser.add_argument("--quiet", action="store_true", help="httpx 등 로그 출력 최소화")
    parser.add_argument("--selfcheck", action="store_true",
                        help="프로그램 파일이 사라졌는지만 점검하고 종료(런처가 실행 직전에 사용)")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.WARNING if args.quiet else logging.INFO,
        format="%(message)s",
    )
    if args.quiet:
        logging.getLogger("httpx").setLevel(logging.WARNING)

    out_dir_str = (args.out_dir or _load_config().get("out_dir") or "").strip()
    out_dir = Path(out_dir_str).expanduser() if out_dir_str else _default_out_dir()
    out_dir.mkdir(parents=True, exist_ok=True)

    all_results: list[FileResult] = []
    opened_dirs: set[str] = set()

    if args.interactive:
        print("=" * 52)
        print(" 📥 공고 첨부파일 자동 다운로드")
        print(" 공고 상세페이지 주소를 붙여넣고 Enter.")
        print(" · 여러 개: 한 줄에 띄어쓰기로 이어 붙이거나")
        print("           여러 줄(한 줄에 하나씩) 붙여넣어도 됩니다.")
        print(" · 빈 줄에서 Enter = 종료")
        print(f" 저장 폴더: {out_dir}")
        print("=" * 52)
        while True:
            try:
                line = input("\n🔗 공고 링크 붙여넣기: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not line:
                break
            targets = re.findall(r"https?://[^\s'\"]+", line) or [line]
            if len(targets) > 1:
                print(f"  🔢 링크 {len(targets)}개 감지 — 차례로 받습니다")
            for u in targets:
                _handle_url(u, out_dir, args.dry_run, True, opened_dirs, all_results)
            _write_manifest(out_dir, args.dry_run, all_results)
        if all_results:
            counts: dict[str, int] = {}
            for r in all_results:
                counts[r.status] = counts.get(r.status, 0) + 1
            _print_summary(counts, len({r.detail_url for r in all_results}))
            if args.notify and not args.dry_run:
                ok = counts.get("DOWNLOADED", 0)
                if ok:
                    _notify_download_done(ok, len({r.detail_url for r in all_results}), out_dir)
        else:
            print("받은 파일이 없습니다.")
        return 0

    urls = load_urls(args)
    if not urls:
        print("❌ 받을 링크가 없습니다. 공고 상세 페이지 URL 을 입력하세요.")
        return 2

    for url in urls:
        _handle_url(url, out_dir, args.dry_run, args.open, opened_dirs, all_results)
    counts = _write_manifest(out_dir, args.dry_run, all_results)
    _print_summary(counts, len(urls))
    if args.notify and not args.dry_run and counts.get("DOWNLOADED", 0):
        _notify_download_done(counts["DOWNLOADED"], len(urls), out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
